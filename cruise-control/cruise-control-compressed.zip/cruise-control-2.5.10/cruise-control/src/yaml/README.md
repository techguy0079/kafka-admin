### Build Wiki
**Prereq:** npm, redoc-cli (npm module)

Run at base directory
```
./gradlew buildApiWiki
```

**Output directory:** target/api\_wiki
